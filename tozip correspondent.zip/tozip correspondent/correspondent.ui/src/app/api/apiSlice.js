import {createApi, fetchBaseQuery} from '@reduxjs/toolkit/query/react'

import {setCredentials, logOut} from '../../features/auth/authSlice'

const baseQuery = fetchBaseQuery({
    baseUrl: 'http://localhost:8000/',
    setCredentials: 'include',//cookies
    prepareHeaders:(headers, {getState}) => {
        const token = getState().auth.token  //we want to send access token everytime 
        if(token){
             
             headers.set('Authorization', `Bearer ${token}`)//authenticated / authorization backend should be looking 
             //we are attaching the access token to header everytime with every request
        }
        return headers
    }
})


//if it fail of access token time expire we can reattempt after sending refresh token and getting a new accesss token
//this function will allows us to get new access token
const baseQueryWithReauth = async (args, api, extraOptions) => { //10:40
     
    let result = await baseQuery(args, api, extraOptions)
    
    //if we find any error like 403 will get into this condition else login
    if(result?.error?.originalStatus === 403){
        console.log('Sending refresh token')

        //send refresh token to get new access token
        const refreshResult = await baseQuery('/refresh', api, extraOptions)
        console.log(refreshResult)

        if(refreshResult?.data){
            
            const user = api.getState().auth.user
            
            //store the new token
            api.dispatch(setCredentials({
                ...refreshResult.data,
                user
            }))

            //retry the original query with new access token
            result = await baseQuery(args, api, extraOptions)
        }
        else{
            api.dispatch(logOut())
        }
    }
    return result 
}

export const apiSlice = createApi({
    baseQuery: baseQueryWithReauth,
    endpoints: builder => ({})
})